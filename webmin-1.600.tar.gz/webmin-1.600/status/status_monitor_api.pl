
# status_monitor_list()
# Returns a list of monitor types defined by this module, each of which must
# be a two-element array reference
sub status_monitor_list
{
}

# status_monitor_status(type, &monitor)
# Returns a status object for some montor with the give name and info structure
sub status_monitor_status
{
}

# status_monitor_dialog(type, &monitor)
# Returns HTML for a dialog for options for a monitor of the given type
sub status_monitor_dialog
{
}

# status_monitor_parse(type, &monitor, &in)
# Updates the monitor object with values from the form
sub status_monitor_parse
{
}

1;

